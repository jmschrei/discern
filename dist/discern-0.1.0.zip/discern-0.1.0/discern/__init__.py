# __init__.py
# Contact: Jacob Schreiber
#          jmschr@cs.washington.edu

from discern import *

__version__ = '0.1.0'
